import { useState } from 'react';
import { Head, usePage, router } from '@inertiajs/react';
import { useTranslation } from 'react-i18next';
import { useDeleteHandler } from '@/hooks/useDeleteHandler';
import { usePageButtons } from '@/hooks/usePageButtons';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PerPageSelector } from '@/components/ui/per-page-selector';
import AuthenticatedLayout from '@/layouts/authenticated-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import { Dialog } from '@/components/ui/dialog';
import { ConfirmationDialog } from '@/components/ui/confirmation-dialog';
import {
    Plus,
    Edit,
    Trash2,
    Key,
    Users as UsersIcon,
    User as UserIcon,
    UserCheck,
    History,
    Lock,
    Zap,
} from 'lucide-react';
import { getImagePath } from '@/utils/helpers';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { FilterButton } from '@/components/ui/filter-button';
import { Pagination } from '@/components/ui/pagination';
import { SearchInput } from '@/components/ui/search-input';
import { ListGridToggle } from '@/components/ui/list-grid-toggle';
import Create from './create';
import EditUser from './edit';
import ChangePassword from './change-password';
import AssignPlan from './assign-plan';
import NoRecordsFound from '@/components/no-records-found';
import { User, UsersIndexProps, UserFilters, UserModalState } from './types';

export default function Index() {
    const { t } = useTranslation();
    const { users, roles, auth, plans } = usePage<UsersIndexProps>().props;
    const urlParams = new URLSearchParams(window.location.search);

    const [filters, setFilters] = useState<UserFilters>({
        name: urlParams.get('name') || '',
        email: urlParams.get('email') || '',
        role: urlParams.get('role') || '',
        is_enable_login: urlParams.get('is_enable_login') || '',
    });

    const [perPage] = useState(urlParams.get('per_page') || '10');
    const [sortField, setSortField] = useState(urlParams.get('sort') || '');
    const [sortDirection, setSortDirection] = useState(urlParams.get('direction') || 'asc');

    const [viewMode, setViewMode] = useState<'list' | 'grid'>((urlParams.get('view') as 'list' | 'grid') || 'list');
    const [modalState, setModalState] = useState<UserModalState>({
        isOpen: false,
        mode: '',
        data: null,
    });
    const [showFilters, setShowFilters] = useState(false);

    // Add hook here
    const pageButtons = usePageButtons('userBtn', 'Test data');

    const { deleteState, openDeleteDialog, closeDeleteDialog, confirmDelete } = useDeleteHandler({
        routeName: 'users.destroy',
        defaultMessage: t('Are you sure you want to delete this user?'),
    });

    const handleFilter = () => {
        router.get(
            route('users.index'),
            { ...filters, per_page: perPage, sort: sortField, direction: sortDirection, view: viewMode },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    const handleSort = (field: string) => {
        const direction = sortField === field && sortDirection === 'asc' ? 'desc' : 'asc';
        setSortField(field);
        setSortDirection(direction);
        router.get(
            route('users.index'),
            { ...filters, per_page: perPage, sort: field, direction, view: viewMode },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    const clearFilters = () => {
        setFilters({ name: '', email: '', role: '', is_enable_login: '' });
        router.get(route('users.index'), { per_page: perPage, view: viewMode });
    };

    const openModal = (mode: 'add' | 'edit' | 'change-password' | 'assign-plan', data: User | null = null) => {
        setModalState({
            isOpen: true,
            mode,
            data,
        });
    };

    const closeModal = () => {
        setModalState({
            isOpen: false,
            mode: '',
            data: null,
        });
    };

    const tableColumns = [
        {
            key: 'avatar',
            header: t('Avatar'),
            render: (value: string) => (
                <div className="flex h-10 w-10 items-center justify-center overflow-hidden rounded-lg border bg-muted">
                    {value ? (
                        <img src={getImagePath(value)} alt="Avatar" className="h-full w-full object-cover" />
                    ) : (
                        <UserIcon className="h-5 w-5 text-muted-foreground" />
                    )}
                </div>
            ),
        },
        {
            key: 'name',
            header: t('Name'),
            sortable: true,
        },
        {
            key: 'email',
            header: t('Email'),
            sortable: true,
        },
        {
            key: 'mobile_no',
            header: t('Mobile No'),
        },
        {
            key: 'type',
            header: t('Role'),
            sortable: true,
            render: (value: string) => (
                <span className="rounded-full bg-muted px-2 py-1 text-sm capitalize">{value}</span>
            ),
        },
        {
            key: 'is_enable_login',
            header: t('Login Status'),
            sortable: true,
            render: (value: boolean) => (
                <span
                    className={`rounded-full px-2 py-1 text-sm ${
                        value ? 'bg-muted text-foreground' : 'bg-muted/50 text-muted-foreground'
                    }`}
                >
                    {value ? t('Enabled') : t('Disabled')}
                </span>
            ),
        },
        ...(auth.user?.permissions?.some((p: string) =>
            ['change-password-users', 'edit-users', 'delete-users'].includes(p)
        )
            ? [
                  {
                      key: 'actions',
                      header: t('Actions'),
                      render: (_: any, user: User) => (
                          <div className="flex gap-1">
                              {user.is_disable === 1 ? (
                                  <Tooltip delayDuration={0}>
                                      <TooltipTrigger asChild>
                                          <div className="flex h-8 w-8 items-center justify-center p-0 text-muted-foreground">
                                              <Lock className="h-4 w-4" />
                                          </div>
                                      </TooltipTrigger>
                                      <TooltipContent>
                                          <p>{t('User is disabled')}</p>
                                      </TooltipContent>
                                  </Tooltip>
                              ) : (
                                  <TooltipProvider>
                                      {auth.user?.permissions?.includes('impersonate-users') &&
                                          user.id !== auth.user?.id && (
                                              <Tooltip delayDuration={0}>
                                                  <TooltipTrigger asChild>
                                                      <Button
                                                          variant="ghost"
                                                          size="sm"
                                                          onClick={() =>
                                                              router.post(route('users.impersonate', user.id))
                                                          }
                                                          className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                                                      >
                                                          <UserCheck className="h-4 w-4" />
                                                      </Button>
                                                  </TooltipTrigger>
                                                  <TooltipContent>
                                                      <p>{t('Login As User')}</p>
                                                  </TooltipContent>
                                              </Tooltip>
                                          )}
                                      {auth.user?.type === 'superadmin' && user.type === 'company' && (
                                          <Tooltip delayDuration={0}>
                                              <TooltipTrigger asChild>
                                                  <Button
                                                      variant="ghost"
                                                      size="sm"
                                                      onClick={() => openModal('assign-plan', user)}
                                                      className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                                                  >
                                                      <Zap className="h-4 w-4" />
                                                  </Button>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                  <p>{t('Assign Plan')}</p>
                                              </TooltipContent>
                                          </Tooltip>
                                      )}
                                      {auth.user?.permissions?.includes('change-password-users') && (
                                          <Tooltip delayDuration={0}>
                                              <TooltipTrigger asChild>
                                                  <Button
                                                      variant="ghost"
                                                      size="sm"
                                                      onClick={() => openModal('change-password', user)}
                                                      className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                                                  >
                                                      <Key className="h-4 w-4" />
                                                  </Button>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                  <p>{t('Change Password')}</p>
                                              </TooltipContent>
                                          </Tooltip>
                                      )}
                                      {auth.user?.permissions?.includes('edit-users') && (
                                          <Tooltip delayDuration={0}>
                                              <TooltipTrigger asChild>
                                                  <Button
                                                      variant="ghost"
                                                      size="sm"
                                                      onClick={() => openModal('edit', user)}
                                                      className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground"
                                                  >
                                                      <Edit className="h-4 w-4" />
                                                  </Button>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                  <p>{t('Edit')}</p>
                                              </TooltipContent>
                                          </Tooltip>
                                      )}
                                      {auth.user?.permissions?.includes('delete-users') && (
                                          <Tooltip delayDuration={0}>
                                              <TooltipTrigger asChild>
                                                  <Button
                                                      variant="ghost"
                                                      size="sm"
                                                      onClick={() => openDeleteDialog(user.id)}
                                                      className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                                  >
                                                      <Trash2 className="h-4 w-4" />
                                                  </Button>
                                              </TooltipTrigger>
                                              <TooltipContent>
                                                  <p>{t('Delete')}</p>
                                              </TooltipContent>
                                          </Tooltip>
                                      )}
                                  </TooltipProvider>
                              )}
                          </div>
                      ),
                  },
              ]
            : []),
    ];

    return (
        <AuthenticatedLayout
            breadcrumbs={[{ label: t('Users') }]}
            pageTitle={t('Manage Users')}
            pageActions={
                <div className="flex gap-2">
                    <TooltipProvider>
                        {auth.user?.permissions?.includes('view-login-history') && (
                            <Tooltip delayDuration={0}>
                                <TooltipTrigger asChild>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={() => router.get(route('users.login-history'))}
                                    >
                                        <History className="h-4 w-4" />
                                    </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p>{t('User Login History')}</p>
                                </TooltipContent>
                            </Tooltip>
                        )}
                        {auth.user?.permissions?.includes('create-users') && (
                            <Tooltip delayDuration={0}>
                                <TooltipTrigger asChild>
                                    <Button size="sm" onClick={() => openModal('add')}>
                                        <Plus className="h-4 w-4" />
                                    </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p>{t('Create')}</p>
                                </TooltipContent>
                            </Tooltip>
                        )}
                        {pageButtons.map((button) => (
                            <div key={button.id}>{button.component}</div>
                        ))}
                    </TooltipProvider>
                </div>
            }
        >
            <Head title={t('Users')} />

            {/* Main Content Card */}
            <Card className="shadow-sm">
                {/* Search & Controls Header */}
                <CardContent className="bg-muted/50/50 border-b p-6">
                    <div className="flex items-center justify-between gap-4">
                        <div className="max-w-md flex-1">
                            <SearchInput
                                value={filters.name}
                                onChange={(value) => setFilters({ ...filters, name: value })}
                                onSearch={handleFilter}
                                placeholder={t('Search users...')}
                            />
                        </div>
                        <div className="flex items-center gap-3">
                            <ListGridToggle
                                currentView={viewMode}
                                routeName="users.index"
                                filters={{ ...filters, per_page: perPage }}
                            />
                            <PerPageSelector routeName="users.index" filters={{ ...filters, view: viewMode }} />
                            <div className="relative">
                                <FilterButton showFilters={showFilters} onToggle={() => setShowFilters(!showFilters)} />
                                {(() => {
                                    const activeFilters = [filters.email, filters.role, filters.is_enable_login].filter(
                                        Boolean
                                    ).length;
                                    return (
                                        activeFilters > 0 && (
                                            <span className="absolute -end-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-foreground text-xs font-medium text-background">
                                                {activeFilters}
                                            </span>
                                        )
                                    );
                                })()}
                            </div>
                        </div>
                    </div>
                </CardContent>

                {/* Advanced Filters */}
                {showFilters && (
                    <CardContent className="border-b bg-muted/30 p-6">
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
                            <div>
                                <label className="mb-2 block text-sm font-medium text-foreground">{t('Email')}</label>
                                <Input
                                    placeholder={t('Filter by email')}
                                    value={filters.email}
                                    onChange={(e) => setFilters({ ...filters, email: e.target.value })}
                                />
                            </div>
                            {auth.user?.permissions?.includes('manage-roles') && (
                                <div>
                                    <label className="mb-2 block text-sm font-medium text-foreground">
                                        {t('Role')}
                                    </label>
                                    <Select
                                        value={filters.role}
                                        onValueChange={(value) => setFilters({ ...filters, role: value })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder={t('Filter by role')} />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {Object.entries(roles).map(([name, label]) => (
                                                <SelectItem key={name} value={name}>
                                                    {label}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            )}
                            <div>
                                <label className="mb-2 block text-sm font-medium text-foreground">
                                    {t('Login Status')}
                                </label>
                                <Select
                                    value={filters.is_enable_login}
                                    onValueChange={(value) => setFilters({ ...filters, is_enable_login: value })}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('Filter by login status')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="1">{t('Enabled')}</SelectItem>
                                        <SelectItem value="0">{t('Disabled')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="flex items-end gap-2">
                                <Button onClick={handleFilter} size="sm">
                                    {t('Apply')}
                                </Button>
                                <Button variant="outline" onClick={clearFilters} size="sm">
                                    {t('Clear')}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                )}

                {/* Table Content */}
                <CardContent className="p-0">
                    {viewMode === 'list' ? (
                        <div className="scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100 max-h-[70vh] w-full overflow-y-auto rounded-none">
                            <div className="min-w-[800px]">
                                <DataTable
                                    data={users.data}
                                    columns={tableColumns}
                                    onSort={handleSort}
                                    sortKey={sortField}
                                    sortDirection={sortDirection as 'asc' | 'desc'}
                                    className="rounded-none"
                                    emptyState={
                                        <NoRecordsFound
                                            icon={UsersIcon}
                                            title={t('No users found')}
                                            description={t('Get started by creating your first user.')}
                                            hasFilters={
                                                !!(
                                                    filters.name ||
                                                    filters.email ||
                                                    filters.role ||
                                                    filters.is_enable_login
                                                )
                                            }
                                            onClearFilters={clearFilters}
                                            createPermission="create-users"
                                            onCreateClick={() => openModal('add')}
                                            createButtonText={t('Create User')}
                                            className="h-auto"
                                        />
                                    }
                                />
                            </div>
                        </div>
                    ) : (
                        <div className="max-h-[70vh] overflow-auto p-4">
                            {users.data.length > 0 ? (
                                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
                                    {users.data.map((user) => (
                                        <Card key={user.id} className="border border-border">
                                            <div className="p-4">
                                                <div className="mb-3 flex items-center gap-3">
                                                    <div className="h-10 w-10 flex-shrink-0 overflow-hidden rounded-lg border bg-muted">
                                                        {user.avatar ? (
                                                            <img
                                                                src={getImagePath(user.avatar)}
                                                                alt={user.name}
                                                                className="h-full w-full object-cover"
                                                            />
                                                        ) : (
                                                            <div className="flex h-full w-full items-center justify-center">
                                                                <UserIcon className="h-5 w-5 text-foreground" />
                                                            </div>
                                                        )}
                                                    </div>
                                                    <div className="flex-1">
                                                        <h3 className="text-base font-semibold text-foreground">
                                                            {user.name}
                                                        </h3>
                                                    </div>
                                                </div>

                                                <div className="mb-3 space-y-3">
                                                    <div>
                                                        <p className="mb-2 text-xs font-medium text-muted-foreground">
                                                            {t('Email')}
                                                        </p>
                                                        <p
                                                            className="truncate text-xs text-foreground"
                                                            title={user.email}
                                                        >
                                                            {user.email}
                                                        </p>
                                                    </div>

                                                    <div className="grid grid-cols-2 gap-2">
                                                        <div>
                                                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                {t('Role')}
                                                            </p>
                                                            <p className="truncate text-xs capitalize text-foreground">
                                                                {user.type}
                                                            </p>
                                                        </div>
                                                        {user.mobile_no && (
                                                            <div>
                                                                <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                    {t('Mobile')}
                                                                </p>
                                                                <p className="text-xs text-foreground">
                                                                    {user.mobile_no}
                                                                </p>
                                                            </div>
                                                        )}
                                                    </div>
                                                </div>

                                                <div className="flex items-center justify-between border-t pt-3">
                                                    <span
                                                        className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-semibold ${
                                                            user.is_enable_login
                                                                ? 'bg-muted text-foreground'
                                                                : 'bg-muted/50 text-muted-foreground'
                                                        }`}
                                                    >
                                                        {user.is_enable_login ? t('Enabled') : t('Disabled')}
                                                    </span>
                                                    <div className="flex gap-1">
                                                        {user.is_disable === 1 ? (
                                                            <Tooltip delayDuration={300}>
                                                                <TooltipTrigger asChild>
                                                                    <div className="flex h-8 w-8 items-center justify-center p-0 text-muted-foreground">
                                                                        <Lock className="h-4 w-4" />
                                                                    </div>
                                                                </TooltipTrigger>
                                                                <TooltipContent>
                                                                    <p>{t('User is disabled')}</p>
                                                                </TooltipContent>
                                                            </Tooltip>
                                                        ) : (
                                                            <TooltipProvider>
                                                                {auth.user?.permissions?.includes(
                                                                    'impersonate-users'
                                                                ) &&
                                                                    user.id !== auth.user?.id && (
                                                                        <Tooltip delayDuration={300}>
                                                                            <TooltipTrigger asChild>
                                                                                <Button
                                                                                    variant="ghost"
                                                                                    size="sm"
                                                                                    onClick={() =>
                                                                                        router.post(
                                                                                            route(
                                                                                                'users.impersonate',
                                                                                                user.id
                                                                                            )
                                                                                        )
                                                                                    }
                                                                                    className="h-8 w-8 p-0 text-muted-foreground"
                                                                                >
                                                                                    <UserCheck className="h-4 w-4" />
                                                                                </Button>
                                                                            </TooltipTrigger>
                                                                            <TooltipContent>
                                                                                <p>{t('Login As User')}</p>
                                                                            </TooltipContent>
                                                                        </Tooltip>
                                                                    )}
                                                                {auth.user?.type === 'superadmin' &&
                                                                    user.type === 'company' && (
                                                                        <Tooltip delayDuration={300}>
                                                                            <TooltipTrigger asChild>
                                                                                <Button
                                                                                    variant="ghost"
                                                                                    size="sm"
                                                                                    onClick={() =>
                                                                                        openModal('assign-plan', user)
                                                                                    }
                                                                                    className="h-8 w-8 p-0 text-muted-foreground hover:bg-accent"
                                                                                >
                                                                                    <Zap className="h-4 w-4" />
                                                                                </Button>
                                                                            </TooltipTrigger>
                                                                            <TooltipContent>
                                                                                <p>{t('Assign Plan')}</p>
                                                                            </TooltipContent>
                                                                        </Tooltip>
                                                                    )}
                                                                {auth.user?.permissions?.includes(
                                                                    'change-password-users'
                                                                ) && (
                                                                    <Tooltip delayDuration={300}>
                                                                        <TooltipTrigger asChild>
                                                                            <Button
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                onClick={() =>
                                                                                    openModal('change-password', user)
                                                                                }
                                                                                className="h-8 w-8 p-0 text-muted-foreground"
                                                                            >
                                                                                <Key className="h-4 w-4" />
                                                                            </Button>
                                                                        </TooltipTrigger>
                                                                        <TooltipContent>
                                                                            <p>{t('Change Password')}</p>
                                                                        </TooltipContent>
                                                                    </Tooltip>
                                                                )}
                                                                {auth.user?.permissions?.includes('edit-users') && (
                                                                    <Tooltip delayDuration={300}>
                                                                        <TooltipTrigger asChild>
                                                                            <Button
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                onClick={() => openModal('edit', user)}
                                                                                className="h-8 w-8 p-0 text-muted-foreground"
                                                                            >
                                                                                <Edit className="h-4 w-4" />
                                                                            </Button>
                                                                        </TooltipTrigger>
                                                                        <TooltipContent>
                                                                            <p>{t('Edit')}</p>
                                                                        </TooltipContent>
                                                                    </Tooltip>
                                                                )}
                                                                {auth.user?.permissions?.includes('delete-users') && (
                                                                    <Tooltip delayDuration={300}>
                                                                        <TooltipTrigger asChild>
                                                                            <Button
                                                                                variant="ghost"
                                                                                size="sm"
                                                                                onClick={() =>
                                                                                    openDeleteDialog(user.id)
                                                                                }
                                                                                className="h-8 w-8 p-0 text-destructive"
                                                                            >
                                                                                <Trash2 className="h-4 w-4" />
                                                                            </Button>
                                                                        </TooltipTrigger>
                                                                        <TooltipContent>
                                                                            <p>{t('Delete')}</p>
                                                                        </TooltipContent>
                                                                    </Tooltip>
                                                                )}
                                                            </TooltipProvider>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </Card>
                                    ))}
                                </div>
                            ) : (
                                <NoRecordsFound
                                    icon={UsersIcon}
                                    title={t('No users found')}
                                    description={t('Get started by creating your first user.')}
                                    hasFilters={
                                        !!(filters.name || filters.email || filters.role || filters.is_enable_login)
                                    }
                                    onClearFilters={clearFilters}
                                    createPermission="create-users"
                                    onCreateClick={() => openModal('add')}
                                    createButtonText={t('Create User')}
                                />
                            )}
                        </div>
                    )}
                </CardContent>

                {/* Pagination Footer */}
                <CardContent className="bg-muted/50/30 border-t px-4 py-2">
                    <Pagination
                        data={users}
                        routeName="users.index"
                        filters={{ ...filters, per_page: perPage, view: viewMode }}
                    />
                </CardContent>
            </Card>

            <Dialog open={modalState.isOpen} onOpenChange={closeModal}>
                {modalState.mode === 'add' && <Create onSuccess={closeModal} roles={roles} />}
                {modalState.mode === 'edit' && modalState.data && (
                    <EditUser user={modalState.data} onSuccess={closeModal} roles={roles} />
                )}
                {modalState.mode === 'change-password' && modalState.data && (
                    <ChangePassword user={modalState.data} onSuccess={closeModal} />
                )}
                {modalState.mode === 'assign-plan' && modalState.data && (
                    <AssignPlan user={modalState.data} plans={plans || []} onSuccess={closeModal} />
                )}
            </Dialog>

            <ConfirmationDialog
                open={deleteState.isOpen}
                onOpenChange={closeDeleteDialog}
                title={t('Delete User')}
                message={deleteState.message}
                confirmText={t('Delete')}
                onConfirm={confirmDelete}
                variant="destructive"
            />
        </AuthenticatedLayout>
    );
}
