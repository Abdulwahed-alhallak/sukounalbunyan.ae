import { useState } from 'react';
import { Head, usePage, router } from '@inertiajs/react';
import { useTranslation } from 'react-i18next';
import { useDeleteHandler } from '@/hooks/useDeleteHandler';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { PerPageSelector } from '@/components/ui/per-page-selector';
import AuthenticatedLayout from '@/layouts/authenticated-layout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { DataTable } from '@/components/ui/data-table';
import { Dialog } from '@/components/ui/dialog';
import { ConfirmationDialog } from '@/components/ui/confirmation-dialog';
import { Plus, Edit as EditIcon, Trash2, Eye, Ticket } from 'lucide-react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { FilterButton } from '@/components/ui/filter-button';
import { Pagination } from '@/components/ui/pagination';
import { SearchInput } from '@/components/ui/search-input';
import { ListGridToggle } from '@/components/ui/list-grid-toggle';
import Create from './create';
import Edit from './edit';
import NoRecordsFound from '@/components/no-records-found';
import { HelpdeskTicketsIndexProps, HelpdeskTicketFilters, HelpdeskTicketModalState } from './types';

export default function Index() {
    const { t } = useTranslation();
    const { tickets, categories, companies, auth } = usePage<HelpdeskTicketsIndexProps>().props;
    const urlParams = new URLSearchParams(window.location.search);

    const [filters, setFilters] = useState<HelpdeskTicketFilters>({
        title: urlParams.get('title') || '',
        status: urlParams.get('status') || '',
        priority: urlParams.get('priority') || '',
        category_id: urlParams.get('category_id') || '',
        company_id: urlParams.get('company_id') || '',
    });

    const [perPage] = useState(urlParams.get('per_page') || '10');
    const [sortField, setSortField] = useState(urlParams.get('sort') || '');
    const [sortDirection, setSortDirection] = useState(urlParams.get('direction') || 'asc');
    const [viewMode, setViewMode] = useState<'list' | 'grid'>((urlParams.get('view') as 'list' | 'grid') || 'list');
    const [modalState, setModalState] = useState<HelpdeskTicketModalState>({
        isOpen: false,
        mode: '',
        data: null,
    });
    const [showFilters, setShowFilters] = useState(false);

    const { deleteState, openDeleteDialog, closeDeleteDialog, confirmDelete } = useDeleteHandler({
        routeName: 'helpdesk-tickets.destroy',
        defaultMessage: t('Are you sure you want to delete this ticket?'),
    });

    const handleFilter = () => {
        router.get(
            route('helpdesk-tickets.index'),
            { ...filters, per_page: perPage, sort: sortField, direction: sortDirection, view: viewMode },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    const handleSort = (field: string) => {
        const direction = sortField === field && sortDirection === 'asc' ? 'desc' : 'asc';
        setSortField(field);
        setSortDirection(direction);
        router.get(
            route('helpdesk-tickets.index'),
            { ...filters, per_page: perPage, sort: field, direction, view: viewMode },
            {
                preserveState: true,
                replace: true,
            }
        );
    };

    const clearFilters = () => {
        setFilters({ title: '', status: '', priority: '', category_id: '', company_id: '' });
        router.get(route('helpdesk-tickets.index'), { per_page: perPage, view: viewMode });
    };

    const openModal = (mode: 'add' | 'edit', data: any = null) => {
        setModalState({
            isOpen: true,
            mode,
            data,
        });
    };

    const closeModal = () => {
        setModalState({
            isOpen: false,
            mode: '',
            data: null,
        });
    };

    const getStatusBadge = (status: string) => {
        const colors = {
            open: 'bg-muted text-foreground',
            in_progress: 'bg-muted text-foreground',
            resolved: 'bg-muted text-foreground',
            closed: 'bg-muted text-foreground',
        };
        return (
            <span className={`rounded-full px-2 py-1 text-sm ${colors[status as keyof typeof colors]}`}>
                {t(status.replace('_', ' '))}
            </span>
        );
    };

    const getPriorityBadge = (priority: string) => {
        const colors = {
            low: 'bg-muted text-foreground',
            medium: 'bg-muted text-foreground',
            high: 'bg-muted text-foreground',
            urgent: 'bg-muted text-destructive',
        };
        return (
            <span className={`rounded-full px-2 py-1 text-sm ${colors[priority as keyof typeof colors]}`}>
                {t(priority)}
            </span>
        );
    };

    const tableColumns = [
        {
            key: 'ticket_id',
            header: t('Ticket ID'),
            sortable: true,
            render: (value: string, ticket: any) =>
                auth.user?.permissions?.includes('view-helpdesk-tickets') ? (
                    <span
                        className="cursor-pointer text-foreground hover:text-foreground"
                        onClick={() => router.get(route('helpdesk-tickets.show', ticket.id))}
                    >
                        #{value}
                    </span>
                ) : (
                    `#${value}`
                ),
        },
        {
            key: 'title',
            header: t('Title'),
            sortable: true,
        },
        {
            key: 'category',
            header: t('Category'),
            render: (_: any, ticket: any) => ticket.category?.name || '-',
        },
        {
            key: 'status',
            header: t('Status'),
            sortable: true,
            render: (value: string) => getStatusBadge(value),
        },
        {
            key: 'priority',
            header: t('Priority'),
            sortable: true,
            render: (value: string) => getPriorityBadge(value),
        },
        {
            key: 'creator',
            header: t('Created By'),
            render: (_: any, ticket: any) => ticket.creator?.name || '-',
        },
        ...(auth.user?.permissions?.some((p: string) =>
            ['view-helpdesk-tickets', 'edit-helpdesk-tickets', 'delete-helpdesk-tickets'].includes(p)
        )
            ? [
                  {
                      key: 'actions',
                      header: t('Actions'),
                      render: (_: any, ticket: any) => (
                          <div className="flex gap-1">
                              <TooltipProvider>
                                  {auth.user?.permissions?.includes('view-helpdesk-tickets') && (
                                      <Tooltip delayDuration={0}>
                                          <TooltipTrigger asChild>
                                              <Button
                                                  variant="ghost"
                                                  size="sm"
                                                  onClick={() => router.get(route('helpdesk-tickets.show', ticket.id))}
                                                  className="h-8 w-8 p-0 text-foreground hover:text-foreground"
                                              >
                                                  <Eye className="h-4 w-4" />
                                              </Button>
                                          </TooltipTrigger>
                                          <TooltipContent>
                                              <p>{t('View')}</p>
                                          </TooltipContent>
                                      </Tooltip>
                                  )}
                                  {auth.user?.permissions?.includes('edit-helpdesk-tickets') && (
                                      <Tooltip delayDuration={0}>
                                          <TooltipTrigger asChild>
                                              <Button
                                                  variant="ghost"
                                                  size="sm"
                                                  onClick={() => openModal('edit', ticket)}
                                                  className="h-8 w-8 p-0 text-foreground hover:text-foreground"
                                              >
                                                  <EditIcon className="h-4 w-4" />
                                              </Button>
                                          </TooltipTrigger>
                                          <TooltipContent>
                                              <p>{t('Edit')}</p>
                                          </TooltipContent>
                                      </Tooltip>
                                  )}
                                  {auth.user?.permissions?.includes('delete-helpdesk-tickets') && (
                                      <Tooltip delayDuration={0}>
                                          <TooltipTrigger asChild>
                                              <Button
                                                  variant="ghost"
                                                  size="sm"
                                                  onClick={() => openDeleteDialog(ticket.id)}
                                                  className="h-8 w-8 p-0 text-destructive hover:text-destructive"
                                              >
                                                  <Trash2 className="h-4 w-4" />
                                              </Button>
                                          </TooltipTrigger>
                                          <TooltipContent>
                                              <p>{t('Delete')}</p>
                                          </TooltipContent>
                                      </Tooltip>
                                  )}
                              </TooltipProvider>
                          </div>
                      ),
                  },
              ]
            : []),
    ];

    return (
        <AuthenticatedLayout
            breadcrumbs={[{ label: t('Support Tickets') }]}
            pageTitle={t('Manage Support Tickets')}
            pageActions={
                <div className="flex gap-2">
                    <TooltipProvider>
                        {auth.user?.permissions?.includes('create-helpdesk-tickets') && (
                            <Tooltip delayDuration={0}>
                                <TooltipTrigger asChild>
                                    <Button size="sm" onClick={() => openModal('add')}>
                                        <Plus className="h-4 w-4" />
                                    </Button>
                                </TooltipTrigger>
                                <TooltipContent>
                                    <p>{t('Create')}</p>
                                </TooltipContent>
                            </Tooltip>
                        )}
                    </TooltipProvider>
                </div>
            }
        >
            <Head title={t('Support Tickets')} />

            {/* Main Content Card */}
            <Card className="shadow-sm">
                {/* Search & Controls Header */}
                <CardContent className="bg-muted/50/50 border-b p-6">
                    <div className="flex items-center justify-between gap-4">
                        <div className="max-w-md flex-1">
                            <SearchInput
                                value={filters.title}
                                onChange={(value) => setFilters({ ...filters, title: value })}
                                onSearch={handleFilter}
                                placeholder={t('Search tickets...')}
                            />
                        </div>
                        <div className="flex items-center gap-3">
                            <ListGridToggle
                                currentView={viewMode}
                                routeName="helpdesk-tickets.index"
                                filters={{ ...filters, per_page: perPage }}
                            />
                            <PerPageSelector
                                routeName="helpdesk-tickets.index"
                                filters={{ ...filters, view: viewMode }}
                            />
                            <div className="relative">
                                <FilterButton showFilters={showFilters} onToggle={() => setShowFilters(!showFilters)} />
                                {(() => {
                                    const activeFilters = [
                                        filters.status,
                                        filters.priority,
                                        filters.category_id,
                                        filters.company_id,
                                    ].filter(Boolean).length;
                                    return (
                                        activeFilters > 0 && (
                                            <span className="absolute -end-2 -top-2 flex h-5 w-5 items-center justify-center rounded-full bg-foreground text-xs font-medium text-background">
                                                {activeFilters}
                                            </span>
                                        )
                                    );
                                })()}
                            </div>
                        </div>
                    </div>
                </CardContent>

                {/* Advanced Filters */}
                {showFilters && (
                    <CardContent className="border-b bg-muted/30 p-6">
                        <div className="grid grid-cols-1 gap-4 md:grid-cols-3 lg:grid-cols-4">
                            <div>
                                <label className="mb-2 block text-sm font-medium text-foreground">{t('Status')}</label>
                                <Select
                                    value={filters.status || undefined}
                                    onValueChange={(value) => setFilters({ ...filters, status: value || '' })}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('Filter by status')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="open">{t('Open')}</SelectItem>
                                        <SelectItem value="in_progress">{t('In Progress')}</SelectItem>
                                        <SelectItem value="resolved">{t('Resolved')}</SelectItem>
                                        <SelectItem value="closed">{t('Closed')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="mb-2 block text-sm font-medium text-foreground">
                                    {t('Priority')}
                                </label>
                                <Select
                                    value={filters.priority || undefined}
                                    onValueChange={(value) => setFilters({ ...filters, priority: value || '' })}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('Filter by priority')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem value="low">{t('Low')}</SelectItem>
                                        <SelectItem value="medium">{t('Medium')}</SelectItem>
                                        <SelectItem value="high">{t('High')}</SelectItem>
                                        <SelectItem value="urgent">{t('Urgent')}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div>
                                <label className="mb-2 block text-sm font-medium text-foreground">
                                    {t('Category')}
                                </label>
                                <Select
                                    value={filters.category_id || undefined}
                                    onValueChange={(value) => setFilters({ ...filters, category_id: value || '' })}
                                >
                                    <SelectTrigger>
                                        <SelectValue placeholder={t('Filter by category')} />
                                    </SelectTrigger>
                                    <SelectContent>
                                        {categories?.map((category: any) => (
                                            <SelectItem key={category.id} value={category.id.toString()}>
                                                {category.name}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                            {auth.user?.type === 'superadmin' && (
                                <div>
                                    <label className="mb-2 block text-sm font-medium text-foreground">
                                        {t('User')}
                                    </label>
                                    <Select
                                        value={filters.company_id || undefined}
                                        onValueChange={(value) => setFilters({ ...filters, company_id: value || '' })}
                                    >
                                        <SelectTrigger>
                                            <SelectValue placeholder={t('Filter by User')} />
                                        </SelectTrigger>
                                        <SelectContent>
                                            {companies?.map((company: any) => (
                                                <SelectItem key={company.id} value={company.id.toString()}>
                                                    {company.name}
                                                </SelectItem>
                                            ))}
                                        </SelectContent>
                                    </Select>
                                </div>
                            )}
                            <div className="flex items-end gap-2">
                                <Button onClick={handleFilter} size="sm">
                                    {t('Apply')}
                                </Button>
                                <Button variant="outline" onClick={clearFilters} size="sm">
                                    {t('Clear')}
                                </Button>
                            </div>
                        </div>
                    </CardContent>
                )}

                {/* Table Content */}
                <CardContent className="p-0">
                    {viewMode === 'list' ? (
                        <div className="scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-100 max-h-[70vh] w-full overflow-y-auto rounded-none">
                            <div className="min-w-[800px]">
                                <DataTable
                                    data={tickets.data}
                                    columns={tableColumns}
                                    onSort={handleSort}
                                    sortKey={sortField}
                                    sortDirection={sortDirection as 'asc' | 'desc'}
                                    className="rounded-none"
                                    emptyState={
                                        <NoRecordsFound
                                            icon={Ticket}
                                            title={t('No tickets found')}
                                            description={t('Get started by creating your first support ticket.')}
                                            hasFilters={
                                                !!(
                                                    filters.title ||
                                                    filters.status ||
                                                    filters.priority ||
                                                    filters.category_id ||
                                                    filters.company_id
                                                )
                                            }
                                            onClearFilters={clearFilters}
                                            createPermission="create-helpdesk-tickets"
                                            onCreateClick={() => openModal('add')}
                                            createButtonText={t('Create Ticket')}
                                            className="h-auto"
                                        />
                                    }
                                />
                            </div>
                        </div>
                    ) : (
                        <div className="max-h-[70vh] overflow-auto p-4">
                            {tickets.data.length > 0 ? (
                                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 2xl:grid-cols-5">
                                    {tickets.data.map((ticket) => (
                                        <Card key={ticket.id} className="border border-border">
                                            <div className="p-4">
                                                <div className="mb-3 flex items-center gap-3">
                                                    <div className="rounded-lg bg-foreground/10 p-2">
                                                        <Ticket className="h-5 w-5 text-foreground" />
                                                    </div>
                                                    <div className="flex-1">
                                                        {auth.user?.permissions?.includes('view-helpdesk-tickets') ? (
                                                            <h3
                                                                className="cursor-pointer text-base text-foreground hover:text-foreground"
                                                                onClick={() =>
                                                                    router.get(
                                                                        route('helpdesk-tickets.show', ticket.id)
                                                                    )
                                                                }
                                                            >
                                                                #{ticket.ticket_id}
                                                            </h3>
                                                        ) : (
                                                            <h3 className="text-base text-foreground">
                                                                #{ticket.ticket_id}
                                                            </h3>
                                                        )}
                                                    </div>
                                                </div>

                                                <div className="mb-3 space-y-3">
                                                    <div>
                                                        <p className="mb-2 text-xs font-medium text-muted-foreground">
                                                            {t('Title')}
                                                        </p>
                                                        <p
                                                            className="truncate text-xs text-foreground"
                                                            title={ticket.title}
                                                        >
                                                            {ticket.title}
                                                        </p>
                                                    </div>

                                                    <div className="grid grid-cols-2 gap-2">
                                                        <div>
                                                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                {t('Status')}
                                                            </p>
                                                            <div className="text-xs">
                                                                {getStatusBadge(ticket.status)}
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                {t('Priority')}
                                                            </p>
                                                            <div className="text-xs">
                                                                {getPriorityBadge(ticket.priority)}
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div className="grid grid-cols-2 gap-2">
                                                        <div>
                                                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                {t('Category')}
                                                            </p>
                                                            <p className="truncate text-xs text-foreground">
                                                                {ticket.category?.name || '-'}
                                                            </p>
                                                        </div>
                                                        <div>
                                                            <p className="mb-1 text-xs font-medium text-muted-foreground">
                                                                {t('Created By')}
                                                            </p>
                                                            <p className="truncate text-xs text-foreground">
                                                                {ticket.creator?.name || '-'}
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div className="flex items-center justify-end border-t pt-3">
                                                    <div className="flex gap-1">
                                                        <TooltipProvider>
                                                            {auth.user?.permissions?.includes(
                                                                'view-helpdesk-tickets'
                                                            ) && (
                                                                <Tooltip delayDuration={300}>
                                                                    <TooltipTrigger asChild>
                                                                        <Button
                                                                            variant="ghost"
                                                                            size="sm"
                                                                            onClick={() =>
                                                                                router.get(
                                                                                    route(
                                                                                        'helpdesk-tickets.show',
                                                                                        ticket.id
                                                                                    )
                                                                                )
                                                                            }
                                                                            className="h-8 w-8 p-0 text-foreground"
                                                                        >
                                                                            <Eye className="h-4 w-4" />
                                                                        </Button>
                                                                    </TooltipTrigger>
                                                                    <TooltipContent>
                                                                        <p>{t('View')}</p>
                                                                    </TooltipContent>
                                                                </Tooltip>
                                                            )}
                                                            {auth.user?.permissions?.includes(
                                                                'edit-helpdesk-tickets'
                                                            ) && (
                                                                <Tooltip delayDuration={300}>
                                                                    <TooltipTrigger asChild>
                                                                        <Button
                                                                            variant="ghost"
                                                                            size="sm"
                                                                            onClick={() => openModal('edit', ticket)}
                                                                            className="h-8 w-8 p-0 text-foreground"
                                                                        >
                                                                            <EditIcon className="h-4 w-4" />
                                                                        </Button>
                                                                    </TooltipTrigger>
                                                                    <TooltipContent>
                                                                        <p>{t('Edit')}</p>
                                                                    </TooltipContent>
                                                                </Tooltip>
                                                            )}
                                                            {auth.user?.permissions?.includes(
                                                                'delete-helpdesk-tickets'
                                                            ) && (
                                                                <Tooltip delayDuration={300}>
                                                                    <TooltipTrigger asChild>
                                                                        <Button
                                                                            variant="ghost"
                                                                            size="sm"
                                                                            onClick={() => openDeleteDialog(ticket.id)}
                                                                            className="h-8 w-8 p-0 text-destructive"
                                                                        >
                                                                            <Trash2 className="h-4 w-4" />
                                                                        </Button>
                                                                    </TooltipTrigger>
                                                                    <TooltipContent>
                                                                        <p>{t('Delete')}</p>
                                                                    </TooltipContent>
                                                                </Tooltip>
                                                            )}
                                                        </TooltipProvider>
                                                    </div>
                                                </div>
                                            </div>
                                        </Card>
                                    ))}
                                </div>
                            ) : (
                                <NoRecordsFound
                                    icon={Ticket}
                                    title={t('No tickets found')}
                                    description={t('Get started by creating your first support ticket.')}
                                    hasFilters={
                                        !!(
                                            filters.title ||
                                            filters.status ||
                                            filters.priority ||
                                            filters.category_id ||
                                            filters.company_id
                                        )
                                    }
                                    onClearFilters={clearFilters}
                                    createPermission="create-helpdesk-tickets"
                                    onCreateClick={() => openModal('add')}
                                    createButtonText={t('Create Ticket')}
                                />
                            )}
                        </div>
                    )}
                </CardContent>

                {/* Pagination Footer */}
                <CardContent className="bg-muted/50/30 border-t px-4 py-2">
                    <Pagination
                        data={tickets}
                        routeName="helpdesk-tickets.index"
                        filters={{ ...filters, per_page: perPage, view: viewMode }}
                    />
                </CardContent>
            </Card>

            <Dialog open={modalState.isOpen} onOpenChange={closeModal}>
                {modalState.mode === 'add' && <Create onSuccess={closeModal} />}
                {modalState.mode === 'edit' && modalState.data && (
                    <Edit ticket={modalState.data} onSuccess={closeModal} />
                )}
            </Dialog>

            <ConfirmationDialog
                open={deleteState.isOpen}
                onOpenChange={closeDeleteDialog}
                title={t('Delete Ticket')}
                message={deleteState.message}
                confirmText={t('Delete')}
                onConfirm={confirmDelete}
                variant="destructive"
            />
        </AuthenticatedLayout>
    );
}
