import { Head, router } from '@inertiajs/react';
import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import AuthenticatedLayout from '@/layouts/authenticated-layout';
import SubscriptionLayout from './subscription-layout';

interface Plan {
    id: number;
    name: string;
    description: string;
    number_of_users: number;
    status: boolean;
    free_plan: boolean;
    modules: string[];
    package_price_yearly: number;
    package_price_monthly: number;
    storage_limit: number;
    trial: boolean;
    trial_days: number;
}

interface Module {
    module: string;
    alias: string;
    image: string;
    monthly_price: number;
    yearly_price: number;
}

interface Props {
    plan: Plan;
    activeModules: Module[];
    userActiveModules: string[];
    bankTransferEnabled: string;
    bankTransferInstructions: string;
    planExpireDate?: string;
}

export default function Subscribe({
    plan,
    activeModules,
    userActiveModules,
    bankTransferEnabled,
    bankTransferInstructions,
    planExpireDate,
}: Props) {
    const { t } = useTranslation();
    const [pricingPeriod, setPricingPeriod] = useState<'monthly' | 'yearly'>('monthly');

    const handleSubscribe = (subscriptionData: any) => {
        console.log('Processing subscription:', subscriptionData);

        // Here you would make the API call to process the subscription
        router.post(route('subscriptions.store'), subscriptionData, {
            onSuccess: () => {
                // Handle successful subscription
            },
            onError: (errors) => {
                console.error('Subscription failed:', errors);
            },
        });
    };

    return (
        <AuthenticatedLayout
            breadcrumbs={[
                { label: t('Plans'), url: route('plans.index') },
                { label: t('Subscribe to') + ' ' + plan.name },
            ]}
            pageTitle={t('Subscribe to Plan')}
        >
            <Head title={t('Subscribe to') + ' ' + plan.name} />

            <div className="space-y-6">
                {/* Pricing Period Toggle */}
                <div className="flex items-center justify-center">
                    <div className="rounded-lg bg-muted p-1 dark:bg-card">
                        <div className="flex items-center">
                            <button
                                onClick={() => setPricingPeriod('monthly')}
                                className={`rounded-md px-4 py-2 text-sm font-medium transition-all duration-200 ${
                                    pricingPeriod === 'monthly'
                                        ? 'bg-card text-foreground shadow-sm dark:bg-muted dark:text-foreground'
                                        : 'text-muted-foreground hover:text-foreground dark:text-muted-foreground dark:hover:text-background'
                                }`}
                            >
                                {t('Monthly')}
                            </button>
                            <button
                                onClick={() => setPricingPeriod('yearly')}
                                className={`rounded-md px-4 py-2 text-sm font-medium transition-all duration-200 ${
                                    pricingPeriod === 'yearly'
                                        ? 'bg-card text-foreground shadow-sm dark:bg-muted dark:text-foreground'
                                        : 'text-muted-foreground hover:text-foreground dark:text-muted-foreground dark:hover:text-background'
                                }`}
                            >
                                {t('Yearly')}
                            </button>
                        </div>
                    </div>
                </div>

                {/* Subscription Layout */}
                <SubscriptionLayout
                    plan={plan}
                    allModules={activeModules}
                    userActiveModules={userActiveModules}
                    pricingPeriod={pricingPeriod}
                    onSubscribe={handleSubscribe}
                    bankTransferEnabled={bankTransferEnabled === 'on'}
                    bankTransferInstructions={bankTransferInstructions}
                    planExpireDate={planExpireDate}
                />
            </div>
        </AuthenticatedLayout>
    );
}
